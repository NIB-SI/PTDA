#!/usr/bin/perl
#---------------------------------------- V1.6 (C) Ench, Sep 2012, Oct 2020 --
#| Usage: $0 [-options] inputdir/ [output.csv]
#| Options:
#|   -outfmt=tags|qval|pval    - output file format (D=tags)
##   -maxpval=value            - pval cutoff value (D=none)
##   -maxqval=value            - identify qval over value (D=none)
##   -index=file.csv           - (optional) index file
#|   inputdir                  - input directory
#|   output.csv                - output file (D=inputdir-outfmt.csv)
#-----------------------------------------------------------------------------
##
## Index file format:
##   up/down index file is tsv file with 3 columns):
##   - 1st: up|down,
##   - 2nd: directory
##   - 3rd: file in dir (must be tsv file)
##
#-----------------------------------------------------------------------------
use strict; use utf8; use Encode;

my @HDRCOLS=("NAME=1","SIZE=4","NOM p-val=7","FDR q-val=8","LEADING EDGE=11");
my $MAXPVAL=undef;	# 0.01
my $MAXQVAL=undef;	# 0.05
my $OUTFMT="tags";
my $DEBUG=$ENV{DEBUG};

my($inpdir,$outf,$index,%index);
my(@col,@hdr,%fn,$f,%name,%size,%tab,@tabhdr);

while (defined($_=decode_utf8(shift))) {my($k,$v)=split('=');
  if (opt($_,"-help",2) or opt($_,"--help",3)) {usage()}
  elsif (opt(($k//=""),"-outfmt",2)) {$OUTFMT=defined($v)?$v:shift//""}
# elsif (opt($k,"-maxpval",5)) {$MAXPVAL=defined($v)?$v:shift//0}
# elsif (opt($k,"-maxqval",5)) {$MAXQVAL=defined($v)?$v:shift//0}
# elsif (opt($k,"-index",2)) {$index=defined($v)?$v:shift//""}
  elsif (/^-/) {usage()}
  elsif (!defined($inpdir)) {($inpdir=$_)=~s/\/+$//}
  elsif (!defined($outf)) {$outf=$_}
  else {usage()}
}
usage() if (!defined($inpdir) or !-d $inpdir);
err("$MAXPVAL: Illegal numeric value") if (($MAXPVAL//0)!~/^\d+(\.\d+)?$/);
err("$MAXQVAL: Illegal numeric value") if (($MAXQVAL//0)!~/^\d+(\.\d+)?$/);
err("$OUTFMT: Illegal output format") if (($OUTFMT//"")!~/^(tags|qval|pval)$/);
err("$index: Index file not found") if (defined($index) and !-f $index);
$outf="$inpdir-${OUTFMT}.csv" if (!defined($outf));
err("%s: Output file already exists",$outf) if (-e $outf);

foreach (@HDRCOLS) {push @hdr,(split('='))[0]; push @col,(split('='))[1]-1}
err("$inpdir: Filename contains spaces") if ($inpdir=~/ /);

parse_updown($index);

filterdata("+",grep{/^up:/} keys %fn);
filterdata("-",grep{/down:/} keys %fn);

open(OUT,">",$outf) || err("$outf: $!");
print OUT map{"$_\n"} @tabhdr;
print OUT
  map{join("\t","$_ $name{$_}",$size{$_},$tab{$_})."\n"}
  idsort2(keys %tab);
close OUT;
print ".. $outf created\n";

#-----------------------------------------------------------------------------
sub parse_updown { my($idxf)=@_; my($i,$k,$dir,$fn,$f,%udt);
  if (defined($idxf)) {
    open(IDX,"<",$idxf) || err("$idxf: $!");
    while (<IDX>) {chomp; s/\r//; $i++; ($k,$dir,$fn)=split("\t");
      if ($k eq "up" or $k eq "down") {
        ($f="$dir/$fn")=~s/\....$//;
        $fn{"$k:$f"}="$inpdir/$dir/$fn";
        $udt{"$k:$dir"}=1;
      }
      elsif ($i>1) {err("$idxf:$i: Illegal index syntax")}
    }
    close IDX;
    for (sort keys %udt) {my($d,$k)=split(':');
      if ($d eq "up" and defined($udt{"down:$k"})) {}
      elsif ($d eq "down" and defined($udt{"up:$k"})) {}
      else {err("$_: up/down mismatch")}
    }
  }
  else { # Files must have "-up" or "-down" in the filename
    foreach (glob("$inpdir/*")) {
      err("$_: Filename contains spaces") if (/ /);
      ($f=(split('/'))[-1])=~s/\....$//;
      if (/-up\./) {$fn{"up:$f"}=$_}
      elsif (!/-down\./) {err("$_: Wrong filename: no -(up|down).")}
      elsif (!-f repl($_,"-down.","-up.")) {err("$_: Missing upreg file")}
      else {$fn{"down:$f"}=$_}
    }
  }
}
#-----------------------------------------------------------------------------
sub filterdata { my($ts,@fnlist)=@_;
  my($f,$k,$id,$sz,$pval,$qval,$lead,$name,@colhdr,%coltag);
  my $col=0;
  foreach $k (sort @fnlist) { ($f=$k)=~s/^(up|down)://; $colhdr[$col]=$f;
    open(INP,"<",$fn{$k}) || err("$fn{$k}: $!");
    chomp($_=<INP>); s/\r$//; $_=join("\t",(split("\t"))[@col]);
    err("$f: Column mismatch") if ($_ ne join("\t",@hdr));
    while (<INP>) {chomp; s/\r$//;
      ($id,$sz,$pval,$qval,$lead)=(split("\t"))[@col];
      $id=unquote($id); $lead=unquote($lead);
      ($id,$name)=split(' ',$id,2); $id=~s/://;
      err("$_: No tags found") if ($lead!~s/^tags=(\d+%).*$/$1/);
      if (defined($MAXPVAL) and $pval>$MAXPVAL) {next}
      elsif (!defined($MAXQVAL)) {$lead="$ts$lead"}
      else {$lead=($qval>$MAXQVAL)?"$ts$ts$lead":"$ts$lead"}
      printf "|%-12s|%5s|%13s|%13s|%s\n",$id,$sz,$pval,$qval,$lead if ($DEBUG);
      if (!$name{$id}) {$name{$id}=$name; $size{$id}=$sz; $coltag{$id}=""}
      elsif ($name{$id} ne $name) {err("$f: ERROR($name<=>$name{$id})")}
      elsif ($size{$id} ne $sz) {err("$f: ERROR($sz<=>$size{$id})")}
      if ($OUTFMT eq "tags") {$coltag{$id}.="$col/$lead,"}
      elsif ($OUTFMT eq "qval") {$coltag{$id}.="$col/$qval,"}
      elsif ($OUTFMT eq "pval") {$coltag{$id}.="$col/$pval,"}
      else {err("PANIC! OUTFMT=($OUTFMT)")}
    }
    close INP; $col++;
  }
  my(@ln);
  push @tabhdr,join("\t",("NAME","SIZE",@colhdr));
  foreach $id (sort keys %coltag) {
    @ln=$tab{$id}?split("\t",$tab{$id}):();
    foreach (split(',',$coltag{$id})) {
      ($col,$lead)=split('/');
      $ln[$col].=$ln[$col]?"/$lead":$lead;
    }
    $tab{$id}=join("\t",map{defined()?$_:""} @ln);
  }
}
#-----------------------------------------------------------------------------
sub usage {open(FN,"<$0") && die grep{s|\$0|$0|,1 if (s/^#\| ?//)} <FN>}
#sub help {open(FN,"<$0") && die grep{s|\$0|$0|,1 if (s/^#[X|] ?//)} <FN>}
sub idsort2 {
  map{s/^.*?\///;$_} sort
  map{join('',map{sprintf("%03d",$_)} split(/\./))."/$_"} @_;
}
sub idsort {map{substr($_,9)} sort map{pack('C9',split(/\./)).$_} @_}
sub unquote {return($_[0]=~/^(["'])(.*?)\1$/?$2:$_[0])}
sub repl {my($f,$re,$str)=@_; $f=~s/\Q$re\E/$str/; return($f)}
sub validh {my $s=join("\t",(split("\t",$_[0]))[@col]); $s eq join("\t",@hdr)}
sub err {my($f)=shift; die @_?sprintf("$f\n",@_):"$f\n"}
sub dirname {my($p)=@_; $p=~s|[^/]+/?$||; $p=~s|\b/$||; $p?$p:"."}
sub opt {my($s,$k,$m)=@_; length($s)>=($m?$m:length($k)) and $k=~/^\Q$s\E/}
#-----------------------------------------------------------------------------
