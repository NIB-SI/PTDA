#!/usr/bin/perl -w
use strict;

my %conv1 = ();
open(FILE, "MERGED_conversion-table_2019-12-19_1_within-gene-model_per-gene_PGSC.txt"); my @file1 = <FILE>; close(FILE); chomp(@file1);
foreach my $line (@file1)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
				my @a = split(/\|/, $s[1]);
				foreach my $a (@a)
				{   ### CAREFUL: here I just overwrote, only kept the last when several genes
						$conv1{$s[0]} = $a;
				}
		}
}

my %conv2 = ();
open(FILE, "MERGED_conversion-table_2019-12-19_2_between-gene-models_per-gene_PGSC.txt"); my @file2 = <FILE>; close(FILE); chomp(@file2);
foreach my $line (@file2)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
				my @a = split(/\|/, $s[1]);
				foreach my $a (@a)
				{   ### CAREFUL: here I just overwrote, only kept the last when several genes
					  $conv2{$s[0]} = $a;
				}
		}
}

open(FILE, "results_comparisons-with-raw-counts.txt"); my @file3 = <FILE>; close(FILE); chomp(@file3);
open(END, ">results_comparisons_ITAG.txt");

my %existingGenes = ();
foreach my $line (@file3)
{   $line =~ s/\s+$//;
		unless ($line eq "")
		{   my @s = split(/\t/, $line);
		    if ($s[0] eq 'geneID')
				{   print END ($s[0]."\t".$s[1]."\t".$s[2]."\t".$s[3]."\t".$s[4]."\n");
				    $existingGenes{$s[0]} = 0;
				}
				elsif (substr($s[0],0,5) eq 'Sotub')
				{   $s[0] = $s[0].".1.1";
				    print END ($s[0]."\t".$s[1]."\t".$s[2]."\t".$s[3]."\t".$s[4]."\n");
						$existingGenes{$s[0]} = 0;
				}
				else
				{   if (exists($conv1{$s[0]}))
				    {   $s[0] = $conv1{$s[0]};
						}
						### CAREFUL: here I just overwrote, only kept the last when several genes
						### CAREFUL: I only left the first occurence of a particular gene ID, so I didn't duplicate the logFCs
						if (exists($conv2{$s[0]}))
						{   my $newID = $conv2{$s[0]};
						    unless (exists($existingGenes{$newID}))
								{   print END ($newID."\t".$s[1]."\t".$s[2]."\t".$s[3]."\t".$s[4]."\n");
								    $existingGenes{$newID} = 0;
								}
						}
				}
		}
}

close(END);
