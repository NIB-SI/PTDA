### differential gene analysis in R, for potato protocols book (Ziva Ramsak)
### last changed: 2020-02-25

### 1) Preparation of the working environment:
# Installation of required packages:
install.packages("stringr")
if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install("limma")
BiocManager::install("edgeR")

# Loading the packages into the working environment:
library("limma")
library("edgeR")
library("stringr")

# Specifying the working directory:
# EXAMPLE: setwd("d:/ZsDocs/_book/4_differential-expression/")
setwd("C:/PATH/TO/ANALYSIS/FOLDER/CONTAINING/THE/INPUT/SUBFOLDER")

### 2) Importing the reads:
counts <- read.table("input/raw_counts.txt", header=T, sep="\t", row.names="GeneID", stringsAsFactors=FALSE)

# Checking column/rownames and the dimensions of the imported table - this should correspond to your sample count and if using the GFF suggested, 48922 reads.
colnames(counts)
rownames(counts)[1:20]
dim(counts)

# 3) Define sample groups for later comparisons
group <- factor(c("ryw_mock", "ryw_mock", "ryw_mock",
                  "ryw_treat_secA", "ryw_treat_secA", "ryw_treat_secA",
                  "ryw_treat_secB", "ryw_treat_secB", "ryw_treat_secB"))

# 4) Specify library sizes for each sample:
reads.raw <- DGEList(counts=counts, group=group,
                     lib.size=c(sum(counts$Rywal_mock1_pool), sum(counts$Rywal_mock2_pool), sum(counts$Rywal_mock3_pool),
                                sum(counts$Rywal_wilga_1_poolA), sum(counts$Rywal_wilga_2_poolA), sum(counts$Rywal_wilga_2_poolA),
                                sum(counts$Rywal_wilga_1_poolB), sum(counts$Rywal_wilga_2_poolB), sum(counts$Rywal_wilga_2_poolB)))
DGEList(counts = counts, lib.size = colSums(counts),
        norm.factors = rep(1,ncol(counts)), samples = NULL,
        group = NULL, genes = NULL, remove.zeros = FALSE)

# 5) Filter low expressed reads and normalise the data
# 5A) For GSEA: keeping all (hence the '>=0')
keep.exprs <- rowSums(reads.raw$counts>50)>=0
table(keep.exprs)
reads.norm <- reads.raw[keep.exprs, keep.lib.sizes=TRUE]
reads.norm <- calcNormFactors(reads.norm)
design <- model.matrix(~0+group)
colnames(design) <- c("mock", "treat_secA", "treat_secB")
v <- voom(reads.norm,design)
write.table(cbind(rownames(v$E), v$E), file="output/results_normalised-matrix_full_GSEA.txt", sep="\t", quote=FALSE, row.names=FALSE)
rm(design, keep.exprs, reads.norm, v)

# 5B) For differential expression: keeping genes, that have over 50 counts in at least 4 samples (hence the '>=4'
# the threshold for "low" depends and varies between analyses (5-10 absolute count is very low)
keep.exprs <- rowSums(reads.raw$counts>50)>=4
table(keep.exprs)
reads.norm <- reads.raw[keep.exprs, keep.lib.sizes=TRUE]
reads.norm <- calcNormFactors(reads.norm)
reads.norm$samples ## check if it makes sense per your experiment


########### DELETE THIS AFTER PRETTY PICTURE
## Plot QC plots using different functions
col = c("gray", "gray", "gray", "blue", "blue", "blue", "yellow", "yellow", "yellow")
par(mar=c(10,2,1,1))
#/output/log10rawcounts_boxplot.pdf
boxplot(log(reads.raw$counts+1,10), las=2, ylab="log10(counts)", col=col, cex=5)
#/output/log10filteredcounts_boxplot.pdf
boxplot(log(reads.norm$counts+1,10), las=2, ylab="log10(counts)", col=col)
#density plots before and after removing low expressed genes
#output/norm_counts_densityplots_raw-n-filtered.pdf
opar <- par()
    par(mfrow=c(1,2), cex = 2)
    nsamples <- ncol(reads.raw$counts)
    col = c("gray", "gray", "gray", "blue", "blue", "blue", "yellow", "yellow", "yellow")
    lcpm <- log(as.matrix(reads.raw$counts),10)
    plot(density(lcpm), col=col[1], lwd=2, ylim=c(0,0.4), las=2, main="", xlab="")
    title(main="A. BEFORE REMOVAL", xlab="Log-cpm")
    abline(v=0, lty=3)
    for (i in 2:nsamples){
        den <- density(lcpm[,i])
        lines(den$x, den$y, col=col[i], lwd=2)
    }
    
    lcpm <- log(as.matrix(reads.norm$counts),10)
    plot(density(lcpm), col=col[1], lwd=2, ylim=c(0,1), las=2, main="", xlab="")
    title(main="B. AFTER REMOVAL", xlab="Log-cpm")
    abline(v=0, lty=3)
    for (i in 2:nsamples){
        den <- density(lcpm[,i])
        lines(den$x, den$y, col=col[i], lwd=2)
    }
    legend("topright", colnames(lcpm), text.col=col, bty="n")
par(opar)

dev.off()



# clear the workspace a bit, before going to comparisons
dev.off()
rm(lcpm); rm(opar); rm(den); rm(i); rm(col); rm(nsamples); rm(keep.exprs)
rm(counts); rm(reads.raw)

########################
## limma-voom protocol
# Create design matrix
design <- model.matrix(~0+group)
colnames(design)
colnames(design) <- c("mock", "treat_secA", "treat_secB")
design
v <- voom(reads.norm,design)
write.table(cbind(rownames(v$E), v$E), file="output/results_normalised-matrix_reduced_GSEA.txt", sep="\t", quote=FALSE, row.names=FALSE)

# 6. Fit linear model for each gene given a series of samples, define contrasts and fit the data given a linear model.
fit <- lmFit(v, design)
contrastMatrix <- makeContrasts("treat_secA-mock", "treat_secB-mock", levels=design)
fit2 <- contrasts.fit(fit, contrastMatrix)
fit2 <- eBayes(fit2)

## Combine different contrasts into one table
colnames(fit2$coefficients) # to get the positions of comparisons from fit2
secAvsMock <- topTable(fit2, coef= 1, number=1000000, sort.by="none")
secBvsMock <- topTable(fit2, coef= 2, number=1000000, sort.by="none")

# [,1] je za logFCje iz vseh primerjav devetih; [,5] je za adjusted P vrednosti (prva in druga vrstica)
results <- cbind(secAvsMock$logFC, secBvsMock$logFC, secAvsMock$adj.P.Val, secBvsMock$adj.P.Val)

colnames(results)
colnames(results) <- c(paste(colnames(fit2$contrasts),"_logFC", sep=""),paste(colnames(fit2$contrasts),"_padj", sep=""))
colnames(results)
rownames(results) <- rownames(secAvsMock)

# add raw expression data and write a file for MapMan
output.results.raw <- merge(x=results, y=reads.norm$counts, by.x="row.names", by.y="row.names", all.x = TRUE, all.y= FALSE, sort= FALSE)
head(output.results.raw)
colnames(output.results.raw)[1] <- 'geneID'
write.table(output.results.raw, file="output/results_comparisons-with-raw-counts.txt", sep="\t", quote=TRUE, row.names=FALSE)

# clean up the space
rm(list=ls())
                                                                                                                                                           
